<?php
/**
 * {@inheritdoc}
 */
namespace Drupal\apitask\Plugin\rest\resource;

use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Drupal\node\Entity\Node;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\rest\ModifiedResourceResponse;
/**
 * Provides a Demo Resource
 *
 * @RestResource(
 *   id = "demo_resource",
 *   label = @Translation("Demo Resource"),
 *   uri_paths = {
 *     "canonical" = "/profile_rest_api/{uid}",
 *   }
 * )
 */
class ApiTask extends ResourceBase
{
  /**
   * Responds to entity GET requests.
   * @return \Drupal\rest\ResourceResponse
   */
  public function get($uid) {
    $data = \Drupal::service('apitask.about_service')->get($uid);
    $response = new ModifiedResourceResponse($data, 200);
    return $response;
  }
}